load('networks_info.mat', 'networks')
iters = 10;
M = 10000;

for i = 1:length(networks)
    output = ['stacking_training_set/' networks{i} '_linkrem10_linkrem20noconn_stacking_training_set.mat'];
    if exist(output, 'file')
        continue;
    end
    display(networks{i})

    load(['sparsified_matrices/' networks{i} '_linkrem10.mat'], 'matrices');
    matrices_orig = matrices;
    load(['sparsified_matrices/' networks{i} '_linkrem10_linkrem20noconn.mat'], 'matrices');

    edges_train = cell(iters,1);
    labels_train = cell(iters,1);
    for j = 1:iters
        [e1,e2] = find(triu(matrices_orig{j}==0,1));
        missing = [e1,e2]; clear e1 e2;
        [e1,e2] = find(triu(matrices_orig{j}-matrices{j},1));
        removed = [e1,e2]; clear e1 e2;
        if size(missing,1) > M
            missing = missing(randsample(size(missing,1),M),:);
        end
        if size(removed,1) > M
            removed = removed(randsample(size(removed,1),M),:);
        end
        edges_train{j} = [missing; removed];
        labels_train{j} = [zeros(size(missing,1),1); ones(size(removed,1),1)];
    end
    save(output, 'edges_train', 'labels_train')
end
