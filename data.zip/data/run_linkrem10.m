load('networks_info.mat', 'networks')

iters = 10;
perc = 0.1;
method_1 = 'rand_conn';
rand_conn_maxiters_test = 100;
method_2 = 'UST';

for i = 1:length(networks)
    
    output = ['sparsified_matrices/' networks{i} '_linkrem10.mat'];
    if exist(output, 'file')
        continue;
    end
    load(['matrices/' networks{i} '.mat'], 'x');
    display(networks{i})
    matrices = cell(iters,1);

    % test method
    [x_test, perc_rem] = random_link_removal(x, perc, method_1, rand_conn_maxiters_test, 1, 1);
    if ~isempty(x_test)
        method = method_1;
    else
        method = method_2;
    end

    parfor j = 1:iters
        matrices{j} = random_link_removal(x, perc, method, [], 0, 0);
    end
    save(output, 'matrices', 'method', 'perc_rem')
    clear x matrices method x_test perc_rem
end
