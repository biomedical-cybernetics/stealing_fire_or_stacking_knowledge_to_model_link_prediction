load('networks_info.mat', 'networks')

iters = 10;
perc = 0.2;
method = 'mindeg1';

for i = 1:length(networks)
    output = ['sparsified_matrices/' networks{i} '_linkrem10_linkrem20noconn.mat'];
    if exist(output, 'file')
        continue;
    end
    load(['sparsified_matrices/' networks{i} '_linkrem10.mat'], 'matrices');
    display(networks{i})

    for j = 1:iters
        matrices{j} = random_link_removal(matrices{j}, perc, method, [], 0, 1);
    end
    save(output, 'matrices')
end
